<a href="<?=$url?>" class="<?=$class?>" data-ajax="false" ><?=$label?></a>
