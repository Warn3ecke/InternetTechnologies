<div class="ui-grid-<?=$class?> dashboard">
    
<?php
Menu::showMenu("dashboard");
?>
    
</div>