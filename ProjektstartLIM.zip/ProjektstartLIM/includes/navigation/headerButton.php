<a href="<?=$url?>" data-role="button" data-mini="true" class="ui-btn ui-shadow ui-corner-all" data-ajax="false" style="color:white"><?=$label?></a>
        