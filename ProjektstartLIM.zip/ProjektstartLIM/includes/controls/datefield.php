<input <?=$disabled?> type='date' data-clear-btn='true' <?=$readonly?> name="<?=$attr?>" id="<?=$attr?>" value="<?=$value?>">
