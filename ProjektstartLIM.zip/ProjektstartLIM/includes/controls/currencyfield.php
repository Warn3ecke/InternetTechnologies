<input <?=$disabled?> <?=$readonly?> type='text' name='<?=$attr?>' class="currency <?=$class?>" id='<?=$attr?>'  value='<?=$value?>'/>


