<input  type='hidden' name='<?=$attr?>' id='<?=$attr?>' value='<?=$value?>' />


