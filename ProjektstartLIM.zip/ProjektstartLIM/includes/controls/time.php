<?php 
// $e= "<input $disabled type='time' name='$attr' id='$attr' placeholder='$label' value='$value' />";
?><input <?=$disabled?> type='time' data-clear-btn='true' name="<?=$attr?>" id="<?=$attr?>" value="<?=$value?>">
