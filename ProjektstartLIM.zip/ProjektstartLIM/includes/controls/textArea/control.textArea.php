<textarea <?=$disabled?> <?=$readonly?> class="<?=$class?> <?=$required?>"name='<?=$attr?>' id='<?=$attr?>' placeholder='<?=$label?>'><?=$value?></textarea> 


