<td><?php
if($src!=""){
?>
<img  class="<?=$class?>" src="<?=$src?>" alt="<?=$label?>"/>
<?php } ?></td>

