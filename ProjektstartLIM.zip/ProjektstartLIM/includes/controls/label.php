<?php /// css muss noch aus der style-Anweisung raus ?>
<label style="width:20%;float:left;margin: .5em 2% 0 0;" for="<?=$attr?>"><?=$label.$required?>:</label>