<input <?=$disabled?> <?=$readonly?> type='file' name='<?=$attr?>' id='<?=$attr?>' placeholder='<?=$label?>' value='<?=$value?>' />


