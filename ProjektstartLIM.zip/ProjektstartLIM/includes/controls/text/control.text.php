<?php
//reiner Text:
echo $value;

