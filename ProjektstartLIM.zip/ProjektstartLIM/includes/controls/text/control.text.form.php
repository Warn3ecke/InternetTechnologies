<div class="ui-input-text formtext">
<input  readonly="readonly" type='text' disabled='<?=$disabled?>' class="formtext" name='<?=$attr?>' id='<?=$attr?>' value='<?=$value?>' data-corners="false" data-enhanced="true"/>
</div>