<td><?php
//reiner Text:
echo $value;
?></td>
