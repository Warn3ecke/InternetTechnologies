 <input <?=$disabled?> <?=$readonly?> type="range" min="<?=$min?>" max="<?=$max?>" value="<?=$value?>" name='<?=$attr?>' class="slider" id='<?=$attr?>'/>
 



