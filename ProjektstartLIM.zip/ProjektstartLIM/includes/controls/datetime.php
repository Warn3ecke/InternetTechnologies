<?php
// $e= "<input $disabled type='datetime' name='$attr' id='$attr' placeholder='$label' value='$value' />";?>
<input <?=$disabled?> type='datetime-local' <?=$readonly?> data-clear-btn='true' name="<?=$attr?>" id="<?=$attr?>" value="<?=$value?>">

