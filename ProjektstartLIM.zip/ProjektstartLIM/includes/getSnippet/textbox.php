<input <?=$disabled?> <?=$readonly?> type='text' name='<?=$attr?>' class="<?=$class?>" id='<?=$attr?>'  value='<?=$value?>' <?php if($mask!=""){echo $mask;}?> <?php
if($placeholder!=""){
    echo $placeholder;

}?>/>


