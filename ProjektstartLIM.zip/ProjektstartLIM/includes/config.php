<?php
$version="1.1.02";
$hostname = "localhost";
$database = "LIMJannisLukas";
$username = "root";
$password = "start123";
$title="ProjektstartLIM";
$defaultTask="home";
$debugmode = 1;
$debugprint= 0;
$debugconsole=1;
$xdebug = 1;
