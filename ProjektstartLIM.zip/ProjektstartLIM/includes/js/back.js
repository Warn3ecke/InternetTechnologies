window.history.go(-2) ;


