<?php

Core::$view->path["view1"]="views/view.error.php";

    


